package com.beyond.bookrental;

public class ConstantURL {

    public static final String url = "https://transvestic-cot.000webhostapp.com/BookBeyond/";
    public static final String PREF = "pref";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String EMAIL = "email";
    public static final String CONTACT = "contact";
    public static final String PASSWORD = "password";


}
